<?php  
include("templates/header.htm");  
include("templates/menu.htm"); 
if (!empty($_GET['page'])) { 
    $action = $_GET['page'];
    $action = basename($action);
    include("templates/$action.htm");   
}else{
	include("templates/home.htm");
	$action = "home";
}


?>
<script type="text/javascript">
	$(document).ready(function () {
		$(".ul-menu li").each(function(n) {
		$(this).removeClass("active");
		});

		/*$(".ul-submenu li").each(function(n) {
		$(this).removeClass("active");
		});*/
		
		var cur_page = '<?php echo $action?>';
		if(cur_page == 'home' || cur_page == 'about' 
		|| cur_page == 'portfolio' || cur_page == 'contact'){
			$("."+cur_page).addClass("active");
		}else{
			$(".services").addClass("active");
		}
		

	});
</script>

<?php

include("templates/footer.htm");

?>